# Smart Cat AI Assistant Icon

This folder contains the plugin icon for display in KiCad's Plugin Manager.

The icon should be:
- 64x64 pixels PNG format
- Named `icon.png`
- Represents a cute cat with glasses (Smart Cat mascot)

For now, we're using a placeholder. The actual icon should be created based on the design specification in `resources/logo_design.md`.
